export const config = { api: { bodyParser: false } };

import formidable from "formidable";
import fs from "fs";
import fetch from "node-fetch";
import FormData from "form-data";

const BOT_TOKEN = "8754066263:AAFOLGvGV7Hml_mRQjf0CmHcg78FgqWHoR4";
const CHAT_ID = "6677015207";

export default async function handler(req,res){
const form = formidable({multiples:false});

form.parse(req,async(err,fields,files)=>{
if(err) return res.json({ok:false});

let msg = `
TEAM FORM

NAME: ${fields.name}
ADDRESS: ${fields.address}
AGE: ${fields.age}
RELIGION: ${fields.religion}
PHONE: ${fields.phone}
EMAIL: ${fields.email}
GENDER: ${fields.gender}
REASON: ${fields.reason}
`;

await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({chat_id:CHAT_ID,text:msg})
});

if(files.video){
let file = files.video;
let fd = new FormData();
fd.append("chat_id",CHAT_ID);
fd.append("video",fs.createReadStream(file.filepath));

await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendVideo`,{
method:"POST",
body:fd
});
}

res.json({ok:true});
});
}
